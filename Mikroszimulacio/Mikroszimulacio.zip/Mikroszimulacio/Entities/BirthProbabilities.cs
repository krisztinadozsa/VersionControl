﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mikroszimulacio.Entities
{
    public class BirthProbabilities
    {
        public int Age { get; set; }
        public int NrbOfChildren { get; set; }
        public double P { get; set; }
    }
}
